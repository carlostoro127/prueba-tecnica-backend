using Clientes.Repositories.Data;
using Clientes.Repositories.Interfaces;
using Clientes.Repositories.Repositories;
using Microsoft.EntityFrameworkCore;
using Clientes.Services.Interfaces;
using Clientes.Services.Services;

var builder = WebApplication.CreateBuilder(args);

// Configuración de Entity Framework Core.
builder.Services.AddDbContext<ClientesDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("ClientesDb")));

// Registro del Repository.
builder.Services.AddScoped<IClienteRepository, ClienteRepository>();
builder.Services.AddScoped<IClienteService, ClienteService>();

// Servicios de API.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configuración de Swagger.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();