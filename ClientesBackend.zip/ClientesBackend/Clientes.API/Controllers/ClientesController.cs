﻿using Clientes.DTOs.Models;
using Clientes.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Clientes.API.Controllers;

/// <summary>
/// Controlador encargado de consultar información de clientes.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class ClientesController : ControllerBase
{
    private readonly IClienteService _clienteService;

    public ClientesController(IClienteService clienteService)
    {
        _clienteService = clienteService;
    }

    /// <summary>
    /// Obtiene un cliente mediante su número de identificación.
    /// </summary>
    /// <param name="identificacion">
    /// Número de identificación del cliente.
    /// </param>
    /// <returns>
    /// Información del cliente si existe.
    /// </returns>
    [HttpGet("{identificacion}")]
    public async Task<ActionResult<ClienteDto>> ObtenerCliente(
        string identificacion)
    {
        var cliente = await _clienteService
            .ObtenerPorIdentificacionAsync(identificacion);

        if (cliente is null)
        {
            return NotFound(new
            {
                mensaje = "Cliente no encontrado."
            });
        }

        return Ok(cliente);
    }
}