﻿namespace Clientes.DTOs
{
    public class Class1
    {

    }
}
