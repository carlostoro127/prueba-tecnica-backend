﻿namespace Clientes.DTOs.Models;

/// <summary>
/// DTO utilizado para exponer la información de un cliente
/// a través de la API.
/// </summary>
public class ClienteDto
{
    public int IdCliente { get; set; }

    public string Identificacion { get; set; } = string.Empty;

    public string Nombre { get; set; } = string.Empty;

    public string Apellido { get; set; } = string.Empty;

    public string? Email { get; set; }

    public string? Telefono { get; set; }
}