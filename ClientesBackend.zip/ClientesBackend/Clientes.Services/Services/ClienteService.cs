﻿using Clientes.DTOs.Models;
using Clientes.Repositories.Interfaces;
using Clientes.Services.Interfaces;

namespace Clientes.Services.Services;

/// <summary>
/// Implementa la lógica de negocio relacionada con los clientes.
/// </summary>
public class ClienteService : IClienteService
{
    private readonly IClienteRepository _clienteRepository;

    public ClienteService(IClienteRepository clienteRepository)
    {
        _clienteRepository = clienteRepository;
    }

    /// <summary>
    /// Obtiene un cliente mediante su número de identificación.
    /// </summary>
    public async Task<ClienteDto?> ObtenerPorIdentificacionAsync(
        string identificacion)
    {
        var cliente = await _clienteRepository
            .ObtenerPorIdentificacionAsync(identificacion);

        if (cliente is null)
        {
            return null;
        }

        return new ClienteDto
        {
            IdCliente = cliente.IdCliente,
            Identificacion = cliente.Identificacion,
            Nombre = cliente.Nombre,
            Apellido = cliente.Apellido,
            Email = cliente.Email,
            Telefono = cliente.Telefono
        };
    }
}