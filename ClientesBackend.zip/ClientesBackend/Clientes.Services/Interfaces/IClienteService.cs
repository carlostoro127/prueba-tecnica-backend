﻿using Clientes.DTOs.Models;

namespace Clientes.Services.Interfaces;

/// <summary>
/// Define las operaciones de negocio relacionadas con los clientes.
/// </summary>
public interface IClienteService
{
    Task<ClienteDto?> ObtenerPorIdentificacionAsync(
        string identificacion);
}