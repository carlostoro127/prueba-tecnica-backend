﻿using Clientes.Repositories.Entities;

namespace Clientes.Repositories.Interfaces;

/// <summary>
/// Define las operaciones de acceso a datos
/// relacionadas con los clientes.
/// </summary>
public interface IClienteRepository
{
    Task<Cliente?> ObtenerPorIdentificacionAsync(
        string identificacion);
}