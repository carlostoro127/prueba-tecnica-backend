﻿using Clientes.Repositories.Entities;
using Microsoft.EntityFrameworkCore;

namespace Clientes.Repositories.Data;

/// <summary>
/// Contexto de acceso a la base de datos DBClientes.
/// </summary>
public class ClientesDbContext : DbContext
{
    public ClientesDbContext(
        DbContextOptions<ClientesDbContext> options)
        : base(options)
    {
    }

    public DbSet<Cliente> Clientes { get; set; }

    /// <summary>
    /// Configura el modelo de datos utilizado por Entity Framework Core.
    /// </summary>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(c => c.IdCliente);

            entity.ToTable("Clientes");

            entity.Property(c => c.IdCliente)
                .ValueGeneratedOnAdd();

            entity.Property(c => c.Identificacion)
                .HasMaxLength(30)
                .IsRequired();

            entity.Property(c => c.Nombre)
                .HasMaxLength(100)
                .IsRequired();

            entity.Property(c => c.Apellido)
                .HasMaxLength(100)
                .IsRequired();

            entity.Property(c => c.Email)
                .HasMaxLength(150);

            entity.Property(c => c.Telefono)
                .HasMaxLength(30);
        });
    }
}