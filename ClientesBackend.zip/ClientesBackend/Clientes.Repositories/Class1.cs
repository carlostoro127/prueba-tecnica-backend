﻿namespace Clientes.Repositories
{
    public class Class1
    {

    }
}
