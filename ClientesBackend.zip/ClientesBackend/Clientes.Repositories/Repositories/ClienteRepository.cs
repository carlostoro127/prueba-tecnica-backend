﻿using Clientes.Repositories.Data;
using Clientes.Repositories.Entities;
using Clientes.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Clientes.Repositories.Repositories;

/// <summary>
/// Implementa el acceso a datos de clientes mediante
/// Entity Framework Core y el procedimiento almacenado.
/// </summary>
public class ClienteRepository : IClienteRepository
{
    private readonly ClientesDbContext _context;

    public ClienteRepository(ClientesDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Obtiene un cliente utilizando su número de identificación.
    /// </summary>
    public async Task<Cliente?> ObtenerPorIdentificacionAsync(
        string identificacion)
    {
        var parametro = new Microsoft.Data.SqlClient.SqlParameter(
            "@Identificacion",
            identificacion);

        var clientes = await _context.Clientes
            .FromSqlRaw(
                "EXEC sp_ObtenerCliente @Identificacion",
                parametro)
            .AsNoTracking()
            .ToListAsync();

        return clientes.FirstOrDefault();
    }
}