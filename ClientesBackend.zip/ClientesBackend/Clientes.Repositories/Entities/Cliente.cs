﻿namespace Clientes.Repositories.Entities;

/// <summary>
/// Representa un cliente almacenado en la base de datos DBClientes.
/// </summary>
public class Cliente
{
    public int IdCliente { get; set; }

    public string Identificacion { get; set; } = string.Empty;

    public string Nombre { get; set; } = string.Empty;

    public string Apellido { get; set; } = string.Empty;

    public string? Email { get; set; }

    public string? Telefono { get; set; }
}